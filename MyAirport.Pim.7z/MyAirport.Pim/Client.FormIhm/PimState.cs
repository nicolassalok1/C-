﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client.FormIhm
{
    public enum PimState
    {
        Deconnecter,
        AttenteBagage,
        SelectionBagage,
        CreationBagage,
        AfichageBagage
    }
}
